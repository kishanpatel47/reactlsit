export default {
  CONTENT_TYPE: {
    APPLICATION_JSON: 'application/json',
  },

  METHODS: {
    POST: 'POST',
    GET: 'GET',
  },

  PARMS: {
    APIKEY: 'HjgfkbXNK6xrgQO2E6QGRm0ohTP1582J',
  },

  API_URLS: {
    // LOCAL: 'http://115.124.111.238:4044/',
    // DAV india   DEVELOPMENT: 'http://115.124.111.238:9005/',
 
 //test      DEVELOPMENT: 'http://192.168.0.245:9051/' ,
 DEVELOPMENT: 'http://gujcob2capi.ethicsinfotech.net/' ,
    // Live        //'http://115.124.96.40:8090/',// Debug
    // LIVE: 'http://davaindia.co.in/',
  },
  API_NAME: {
    AUTHENTICATE: 'web/session/authenticate',
  },
  // Demo Login : 9725895561, otp:251915
};
